
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import static com.google.gson.internal.bind.TypeAdapters.URL;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import static java.lang.System.in;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import jdk.nashorn.internal.parser.JSONParser;
import static jdk.nashorn.tools.ShellFunctions.input;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public class PersonJsonReader {

    public static void main(String[] args) throws IOException {

        String Theurl = "https://www.w3schools.com/angular/customers.php";

        URL url = new URL(Theurl);
        HttpURLConnection request = (HttpURLConnection) url.openConnection();
        request.connect();

        JsonParser jp = new JsonParser();
        JsonElement root = jp.parse(new InputStreamReader((InputStream) request.getContent()));
        JsonObject roJsonObj = root.getAsJsonObject();
        System.out.println(roJsonObj);

        JsonArray jay = roJsonObj.getAsJsonArray("records");
        System.out.println("Json Objects");
        List<Person> persons = new ArrayList();
        for (int i = 0; i < jay.size(); i++) {
            Person person = new Person();
            JsonObject jsonObject = jay.get(i).getAsJsonObject();

            System.out.println(jsonObject.get("Name") + " ");
            person.setName(jsonObject.get("Name").getAsString());

            System.out.println(jsonObject.get("City") + " ");
            person.setCity(jsonObject.get("City").getAsString());

            System.out.println(jsonObject.get("Country")+ " \n----");
            person.setCountry(jsonObject.get("Country").getAsString());

            persons.add(person);

        }

        /*public static void main(String[] args) throws FileNotFoundException {
        Gson gson = new Gson();
        Person[] records = gson.fromJson(new FileReader("https://www.w3schools.com/angular/customers.php"), Person[].class);
        System.out.println(gson.toJson(records));

        public static String readAll(Reader rd) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(rd);
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line );
        }
        return sb.toString();

    }

    private static JsonElement getPath(JsonElement e, String path) {
        JsonElement curr = e;
        String ss[] = path.split(" ");
        for (int i = 0; i < ss.length; i++) {
            curr = curr.getAsJsonObject().get(ss[i]);
        }
        return curr;

    }*/

 /* InputStream is = null;
        is = new URL(url).openStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
        String jsonText = readAll(rd);
        JsonElement je = new JsonParser().parse(jsonText);
        System.out.print(je.toString());
        try {
            if (is != null) {
                is.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }
}
