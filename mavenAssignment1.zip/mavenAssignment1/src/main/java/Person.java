/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author petro
 */
public class Person {

    String name;
    String country;
    String city;

    public Person(String name, String country, String city) {
        this.name = name;
        this.country = country;
        this.city = city;
    }
    

    Person (){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {

        return getName() + " /n"
                + getCity() + " /n" + getCountry();
    }
  
    
    }
