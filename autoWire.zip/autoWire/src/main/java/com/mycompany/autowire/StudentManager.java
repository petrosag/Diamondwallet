package com.mycompany.autowire;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public class StudentManager {

    private static void display() {
        List<Student> student = new ArrayList<>();
        for (Student value : student) {
            System.out.println(value);
        }

    }

    public static void main(String[] args) {
        display();
        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("SpringXMLconfig.xml");
        Student students = (Student) context.getBean("student");

        System.out.println(students.toString());
        Address add = (Address) context.getBean("address");
        System.out.println(add.toString());
        Grade grades = (Grade) context.getBean("grade");

        System.out.println(grades.toString());

    }

}
