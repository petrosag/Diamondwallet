package com.mycompany.autowire;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author petro
 */
public class Student {

   
    String firstname;
    String lastname;
    int DateOfBirth;
    Address address;
    Grade grade;

    public Student() {
        
    }
    public Student(String firstname, String lastname, int DateOfBirth, Address address, Grade grade) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.DateOfBirth = DateOfBirth;
        this.address = address;
        this.grade = grade;
    }
    

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getDateOfBirth() {
        return DateOfBirth;
    }

    public void setDateOfBirth(int DateOfBirth) {
        this.DateOfBirth = DateOfBirth;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student{" + "firstname=" + firstname + ", lastname=" + lastname + ", DateOfBirth=" + DateOfBirth + ", address=" + address + ", grade=" + grade + '}';
    }

   

}
